# Luxury Watch Store

A premium, dark-themed e-commerce site for a men's watch brand.
React 19 + Vite + Tailwind CSS 4 + Motion + React Router, with an optional React Three Fiber 3D viewer.

> **Status:** the source was written and statically checked (all imports, exports, asset paths and JSX syntax resolve),
> but it has **not yet been installed, built or viewed in a browser**. Run the steps below once and report anything
> that looks off.

## Run it

Requires Node.js 18+ (Node 20 or 22 recommended).

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in /dist
npm run preview    # test the production build
```

## What is where

```
public/images/   watch-1…4 (.jpg + .webp, 3:4) and banner (.jpg + .webp)
public/models/   put real .glb/.gltf watch models here (optional)
src/config/brand.js        brand name, announcement text, contact + social placeholders, hero product
src/data/products.js       the four products (name, price, image, description, variants, model3D)
src/data/testimonials.js   real customer reviews (empty until you add them)
src/context/               cart (pure reducer + provider) and UI state (drawer, viewer, search, checkout)
src/components/            all sections and the product viewer
src/pages/                 Home, ProductDetails (/product/:slug), Legal placeholders, NotFound
src/utils/checkout.js      the single place to connect a real payment provider
```

## How to change things

**Brand name** — edit `name` in `src/config/brand.js` (also update `<title>` in `index.html`). The colours
are tokens at the top of `src/index.css` (`--color-gold`, `--color-ink`, …).

**Product images** — replace the files in `public/images/` keeping the names (`watch-1.jpg` + `watch-1.webp`, …).
Use **3:4 portrait** images (e.g. 1200×1600). To make the `.webp`:
`cwebp -q 85 watch-1.jpg -o watch-1.webp` (or delete `imageWebp` from the product to use the JPG only).
Update each product's `alt` text to describe the new photo.

**Names, prices, descriptions** — edit `src/data/products.js`. **Prices in the file are placeholders.**

**Add a watch** — copy one product object, give it a new unique `id` and `slug`, point `image` at a new file.
Grid, search, viewer, prev/next and the product page all pick it up automatically.

**Variants** — e.g. `variants: ['Steel', 'Black']`. A selector appears in the viewer and the choice is kept in the cart.

## Product viewer: photos now, real 3D later

Your four uploads are ordinary photographs, so the viewer is photo-based: smooth zoom, drag-to-pan, a subtle
perspective tilt, floating motion and a light sweep. It deliberately does **not** fake a 360° spin, because a single
photo has no back or sides.

When you have a real model (export from CAD/Blender as `.glb`):

1. Put it in `public/models/watch-1.glb`.
2. In `src/data/products.js` set `model3D: '/models/watch-1.glb'` for that product.

That product then switches to the React Three Fiber viewer: slow auto-rotation, drag/touch rotation, zoom, pause/resume
and reset. three.js is only downloaded when such a product is opened. If WebGL is missing or the model fails to load,
the photo viewer is shown instead.

If you later get several real photos of one watch from different angles, `ImageStage.jsx` is the component to extend
(swap the shown frame as the user drags).

## Checkout and payments (currently a demo)

The cart is real (add, remove, quantities, subtotal, `localStorage` persistence). **Checkout is a demo**: nothing is
charged and no order is created, and the interface says so.

To take real payments, use a hosted checkout (Stripe Checkout, Shopify Buy Button, Lemon Squeezy, PayPal …):

1. Build a small server endpoint that receives `{ items: [{ id, quantity, variant }] }`, **looks up prices on the
   server**, creates a checkout session and replies `{ "url": "https://…" }`.
2. Put its address in `.env`: `VITE_CHECKOUT_ENDPOINT=https://your-server/checkout`.
3. The same modal then becomes "Continue to secure payment" and redirects the customer (see `src/utils/checkout.js`).

Never put secret API keys in this front-end code.

**Newsletter** — also a demo until you set `VITE_NEWSLETTER_ENDPOINT` (it receives `POST { email }`).
Without it, the form validates the address and tells the visitor it was not saved.

**Testimonials** — the section is hidden on production builds until you add real reviews in
`src/data/testimonials.js`. During `npm run dev` it shows clearly labelled sample placeholders.

## Deploy

```bash
npm run build
```

Upload the `dist/` folder, or connect the repo to **Vercel**, **Netlify** or **Cloudflare Pages**
(build command `npm run build`, output directory `dist`). `vercel.json` and `public/_redirects` are included so
routes such as `/product/the-sovereign` work on refresh. Set the `.env` values in the host's dashboard if you use them.

## Before you launch

- Replace the **Privacy Policy** and **Terms** placeholder pages (`src/pages/Legal.jsx`) with real policies.
- Replace contact and social placeholders in `src/config/brand.js`.
- Check that your product photos carry **your** brand, not another company's (see the note in the handover message).
- Only state specifications (water resistance, movement, origin) you can prove — the site copy avoids them on purpose.
