Place real .glb / .gltf watch models here, then set model3D in src/data/products.js (e.g. "/models/watch-1.glb").
