// ─────────────────────────────────────────────────────────────
//  PRODUCT CATALOGUE — edit names, prices, images and details here.
//
//  • price: PLACEHOLDER values — replace with your real prices.
//  • image / imageWebp: files inside /public/images.
//  • model3D: set to a .glb/.gltf path (e.g. "/models/watch-1.glb") to
//    switch that product to the real 3D viewer. Leave null for the
//    photo-based viewer.
//  • variants: optional list of strings, e.g. ["Steel", "Black"].
//    When present, a selector appears in the viewer.
// ─────────────────────────────────────────────────────────────
export const products = [
  {
    id: 1,
    slug: 'the-sovereign',
    name: 'The Sovereign',
    price: 189,
    image: '/images/watch-1.jpg',
    imageWebp: '/images/watch-1.webp',
    alt: 'Stainless steel watch with a black dial, fluted bezel and three sub-dials on a steel bracelet',
    description: 'A refined timepiece designed for modern gentlemen, with a fluted bezel and a commanding black dial.',
    details: ['Fluted polished bezel', 'Three sub-dial layout', 'Stainless steel bracelet'],
    variants: [],
    model3D: null,
  },
  {
    id: 2,
    slug: 'the-eclipse',
    name: 'The Eclipse',
    price: 219,
    image: '/images/watch-2.jpg',
    imageWebp: '/images/watch-2.webp',
    alt: 'Stainless steel watch with a slate-grey sunburst dial and slim baton markers on a steel bracelet',
    description: 'Understated and precise. A slate sunburst dial and slim indices keep the focus on pure form.',
    details: ['Slate sunburst dial', 'Slim baton indices', 'Stainless steel bracelet'],
    variants: [],
    model3D: null,
  },
  {
    id: 3,
    slug: 'the-prestige',
    name: 'The Prestige',
    price: 249,
    image: '/images/watch-3.jpg',
    imageWebp: '/images/watch-3.webp',
    alt: 'Stainless steel watch with a deep green sunburst dial, gold-tone hands and indices on a steel bracelet',
    description: 'A deep green dial warmed by gold-tone accents — made to be noticed without raising its voice.',
    details: ['Green sunburst dial', 'Gold-tone hands and indices', 'Stainless steel bracelet'],
    variants: [],
    model3D: null,
  },
  {
    id: 4,
    slug: 'the-heritage',
    name: 'The Heritage',
    price: 279,
    image: '/images/watch-4.jpg',
    imageWebp: '/images/watch-4.webp',
    alt: 'Stainless steel chronograph-style watch with a textured black dial and three sub-dials on a steel bracelet',
    description: 'Classic chronograph proportions with a textured black dial and a bold, confident wrist presence.',
    details: ['Textured black dial', 'Chronograph-style layout', 'Stainless steel bracelet'],
    variants: [],
    model3D: null,
  },
];

export const getProductById = (id) => products.find((p) => p.id === id);
export const getProductBySlug = (slug) => products.find((p) => p.slug === slug);
