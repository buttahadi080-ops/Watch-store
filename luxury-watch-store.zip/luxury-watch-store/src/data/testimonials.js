// Add REAL customer reviews here. Example:
// { id: 1, name: 'Customer Name', location: 'City', quote: 'What they said.' }
export const testimonials = [];

// Shown ONLY in development (npm run dev) while `testimonials` is empty,
// and always labelled as samples. They never appear on a production build.
export const sampleTestimonials = [
  { id: 's1', name: 'Sample Customer A', location: 'City', quote: 'Sample placeholder — replace with a real customer review.' },
  { id: 's2', name: 'Sample Customer B', location: 'City', quote: 'Sample placeholder — replace with a real customer review.' },
  { id: 's3', name: 'Sample Customer C', location: 'City', quote: 'Sample placeholder — replace with a real customer review.' },
];
