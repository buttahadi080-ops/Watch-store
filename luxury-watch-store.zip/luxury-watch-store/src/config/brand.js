// ─────────────────────────────────────────────────────────────
//  BRAND SETTINGS — edit this file to rebrand the whole website.
// ─────────────────────────────────────────────────────────────
export const BRAND = {
  // Your watch brand name (shown in the logo, footer, page title).
  name: 'MERIDIAN',
  announcement: 'TIMELESS DESIGN. EVERYDAY EXCELLENCE.',
  footerDescription:
    'Watches designed for men who appreciate restraint, presence and the quiet confidence of timeless design.',

  // Product shown large in the hero (matches a product id in data/products.js).
  heroProductId: 4,

  currency: 'USD',
  locale: 'en-US',

  // Contact placeholders — replace with real details.
  contact: {
    email: 'hello@yourbrand.com',
    phone: '+00 000 000 0000',
    address: 'Your Street Address, City, Country',
  },

  // Social placeholders — replace "#" with your real profile URLs.
  social: [
    { label: 'Instagram', href: '#' },
    { label: 'Facebook', href: '#' },
    { label: 'YouTube', href: '#' },
    { label: 'TikTok', href: '#' },
  ],
};
