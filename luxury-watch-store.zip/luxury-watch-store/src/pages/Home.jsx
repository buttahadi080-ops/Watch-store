import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Hero from '../components/Hero.jsx';
import ProductGrid from '../components/ProductGrid.jsx';
import BrandStory from '../components/BrandStory.jsx';
import Features from '../components/Features.jsx';
import BrandBanner from '../components/BrandBanner.jsx';
import Testimonials from '../components/Testimonials.jsx';
import Newsletter from '../components/Newsletter.jsx';

export default function Home() {
  const location = useLocation();

  // Arriving from another page with a target section (see useGoToSection).
  useEffect(() => {
    const id = location.state?.scrollTo;
    if (!id) return;
    const frame = requestAnimationFrame(() => {
      if (id === 'home') window.scrollTo({ top: 0 });
      else document.getElementById(id)?.scrollIntoView({ block: 'start' });
    });
    return () => cancelAnimationFrame(frame);
  }, [location.state]);

  return (
    <>
      <Hero />
      <ProductGrid />
      <BrandStory />
      <Features />
      <BrandBanner />
      <Testimonials />
      <Newsletter />
    </>
  );
}
