import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import ProductShowcase from '../components/ProductShowcase.jsx';
import ProductCard from '../components/ProductCard.jsx';
import NotFound from './NotFound.jsx';
import { getProductBySlug, products } from '../data/products.js';

export default function ProductDetails() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const product = getProductBySlug(slug);

  if (!product) return <NotFound />;

  const index = products.findIndex((p) => p.id === product.id);
  const go = (delta) => navigate(`/product/${products[(index + delta + products.length) % products.length].slug}`);
  const others = products.filter((p) => p.id !== product.id);

  return (
    <div className="container-x pb-24 pt-8">
      <Link to="/" className="mb-6 inline-flex items-center gap-2 text-xs uppercase tracking-[0.22em] text-mist transition-colors hover:text-gold">
        <ArrowLeft size={14} /> Back to collection
      </Link>

      <ProductShowcase key={product.id} product={product} onPrev={() => go(-1)} onNext={() => go(1)} layout="page" />

      <div className="mt-24">
        <h2 className="heading text-3xl">More from the collection</h2>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {others.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
      </div>
    </div>
  );
}
