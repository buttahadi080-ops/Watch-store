import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <section className="container-x flex min-h-[60dvh] flex-col items-center justify-center py-24 text-center">
      <p className="gold-text font-serif text-8xl">404</p>
      <h1 className="heading mt-4 text-3xl">This page has run out of time</h1>
      <p className="mt-4 max-w-md text-mist">The page you are looking for does not exist or has moved.</p>
      <Link to="/" className="btn btn-primary mt-9">Back to home</Link>
    </section>
  );
}
