import { Link } from 'react-router-dom';
import { BRAND } from '../config/brand.js';

const COPY = {
  privacy: { title: 'Privacy Policy' },
  terms: { title: 'Terms & Conditions' },
};

/** Placeholder legal pages. Replace the body text with policies written or reviewed by a qualified professional. */
export default function Legal({ kind }) {
  const { title } = COPY[kind];
  return (
    <section className="container-x max-w-3xl py-20">
      <span className="eyebrow">{BRAND.name}</span>
      <h1 className="heading mt-5 text-4xl">{title}</h1>
      <p className="mt-8 border border-gold/30 bg-gold/5 p-4 text-sm leading-6 text-champagne" role="note">
        Placeholder page. Replace this text with your own {title.toLowerCase()} before taking real orders. It is
        recommended to have it reviewed by a legal professional for the countries you sell to.
      </p>
      <Link to="/" className="btn btn-outline mt-10">Back to home</Link>
    </section>
  );
}
