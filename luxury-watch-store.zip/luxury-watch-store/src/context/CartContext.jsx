import { createContext, useCallback, useContext, useEffect, useMemo, useReducer } from 'react';
import { getProductById } from '../data/products.js';
import { cartReducer, loadCart, saveCart, MAX_QTY } from './cartReducer.js';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [state, dispatch] = useReducer(cartReducer, undefined, loadCart);

  useEffect(() => {
    saveCart(state);
  }, [state]);

  const addItem = useCallback((id, variant = null, qty = 1) => dispatch({ type: 'ADD', id, variant, qty }), []);
  const setQty = useCallback((key, qty) => dispatch({ type: 'SET_QTY', key, qty }), []);
  const removeItem = useCallback((key) => dispatch({ type: 'REMOVE', key }), []);
  const clearCart = useCallback(() => dispatch({ type: 'CLEAR' }), []);

  const value = useMemo(() => {
    const lines = state.items
      .map((i) => ({ ...i, product: getProductById(i.id) }))
      .filter((l) => l.product);
    return {
      lines,
      count: lines.reduce((n, l) => n + l.qty, 0),
      subtotal: lines.reduce((s, l) => s + l.product.price * l.qty, 0),
      maxQty: MAX_QTY,
      addItem,
      setQty,
      removeItem,
      clearCart,
    };
  }, [state, addItem, setQty, removeItem, clearCart]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside <CartProvider>');
  return ctx;
}
