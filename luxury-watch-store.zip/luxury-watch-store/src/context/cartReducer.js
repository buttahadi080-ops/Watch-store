// Pure cart logic — no React, no UI. Easy to test and to replace.
export const STORAGE_KEY = 'watch-store-cart-v1';
export const MAX_QTY = 10;
export const initialCartState = { items: [] };

export const makeKey = (id, variant) => `${id}::${variant ?? ''}`;

export function cartReducer(state, action) {
  switch (action.type) {
    case 'ADD': {
      const { id, variant = null, qty = 1 } = action;
      const key = makeKey(id, variant);
      const existing = state.items.find((i) => i.key === key);
      if (existing) {
        return {
          items: state.items.map((i) => (i.key === key ? { ...i, qty: Math.min(MAX_QTY, i.qty + qty) } : i)),
        };
      }
      return { items: [...state.items, { key, id, variant, qty: Math.min(MAX_QTY, qty) }] };
    }
    case 'SET_QTY': {
      const qty = Math.min(MAX_QTY, action.qty);
      if (qty <= 0) return { items: state.items.filter((i) => i.key !== action.key) };
      return { items: state.items.map((i) => (i.key === action.key ? { ...i, qty } : i)) };
    }
    case 'REMOVE':
      return { items: state.items.filter((i) => i.key !== action.key) };
    case 'CLEAR':
      return initialCartState;
    default:
      return state;
  }
}

export function loadCart() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return initialCartState;
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.items)) return initialCartState;
    const items = parsed.items
      .filter((i) => i && typeof i.key === 'string' && Number.isInteger(i.qty) && i.qty > 0)
      .map((i) => ({ key: i.key, id: i.id, variant: i.variant ?? null, qty: Math.min(MAX_QTY, i.qty) }));
    return { items };
  } catch {
    return initialCartState;
  }
}

export function saveCart(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    /* storage unavailable (private mode / quota) — cart still works in memory */
  }
}
