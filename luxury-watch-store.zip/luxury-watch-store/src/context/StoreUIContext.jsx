import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { products } from '../data/products.js';

const StoreUIContext = createContext(null);

export function StoreUIProvider({ children }) {
  const [cartOpen, setCartOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [checkout, setCheckout] = useState(null); // { lines, fromCart }
  const [viewerId, setViewerId] = useState(null);
  const [viewerDir, setViewerDir] = useState(1);

  const openCart = useCallback(() => setCartOpen(true), []);
  const closeCart = useCallback(() => setCartOpen(false), []);
  const openSearch = useCallback(() => setSearchOpen(true), []);
  const closeSearch = useCallback(() => setSearchOpen(false), []);

  const openViewer = useCallback((id) => {
    setViewerDir(1);
    setViewerId(id);
  }, []);
  const closeViewer = useCallback(() => setViewerId(null), []);
  const stepViewer = useCallback((delta) => {
    setViewerDir(delta);
    setViewerId((cur) => {
      if (cur == null) return cur;
      const i = products.findIndex((p) => p.id === cur);
      return products[(i + delta + products.length) % products.length].id;
    });
  }, []);

  const startCheckout = useCallback((lines, fromCart = false) => {
    if (fromCart) setCartOpen(false);
    setCheckout({ lines, fromCart });
  }, []);
  const closeCheckout = useCallback(() => setCheckout(null), []);

  const value = useMemo(
    () => ({
      cartOpen, openCart, closeCart,
      searchOpen, openSearch, closeSearch,
      checkout, startCheckout, closeCheckout,
      viewerId, viewerDir, openViewer, closeViewer, stepViewer,
    }),
    [cartOpen, searchOpen, checkout, viewerId, viewerDir,
      openCart, closeCart, openSearch, closeSearch, startCheckout, closeCheckout,
      openViewer, closeViewer, stepViewer],
  );

  return <StoreUIContext.Provider value={value}>{children}</StoreUIContext.Provider>;
}

export function useStoreUI() {
  const ctx = useContext(StoreUIContext);
  if (!ctx) throw new Error('useStoreUI must be used inside <StoreUIProvider>');
  return ctx;
}
