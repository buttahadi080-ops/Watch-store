import { BRAND } from '../config/brand.js';

export default function AnnouncementBar() {
  return (
    <div className="relative bg-charcoal text-center">
      <p className="px-4 py-2.5 text-[0.62rem] font-medium uppercase tracking-[0.35em] text-champagne sm:text-[0.68rem]">
        {BRAND.announcement}
      </p>
      <div className="hairline absolute inset-x-0 bottom-0" />
    </div>
  );
}
