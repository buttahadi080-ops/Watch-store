import { useRef } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import ProductImage from './ProductImage.jsx';
import { formatPrice } from '../utils/format.js';
import { useCart } from '../context/CartContext.jsx';
import { useStoreUI } from '../context/StoreUIContext.jsx';
import { useDialog } from '../hooks/useDialog.js';
import { useGoToSection } from '../hooks/useGoToSection.js';

export default function CartDrawer() {
  const { cartOpen, closeCart, startCheckout, checkout } = useStoreUI();
  const { lines, count, subtotal, maxQty, setQty, removeItem } = useCart();
  const goTo = useGoToSection();
  const ref = useRef(null);

  useDialog(cartOpen && !checkout, closeCart, ref);

  const browse = () => {
    closeCart();
    goTo('collection');
  };

  return (
    <AnimatePresence>
      {cartOpen && (
        <div className="fixed inset-0 z-[80]">
          <motion.div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeCart}
            aria-hidden="true"
          />
          <motion.aside
            ref={ref}
            role="dialog"
            aria-modal="true"
            aria-label="Shopping bag"
            tabIndex={-1}
            className="absolute inset-y-0 right-0 flex w-full max-w-md flex-col border-l border-white/10 bg-ink outline-none"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
            <header className="flex items-center justify-between border-b border-white/10 px-6 py-5">
              <h2 className="heading text-2xl">Your Bag{count > 0 && <span className="ml-2 text-base text-mist">({count})</span>}</h2>
              <button type="button" className="icon-btn" aria-label="Close bag" data-autofocus onClick={closeCart}>
                <X size={22} />
              </button>
            </header>

            {lines.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
                <span className="flex h-20 w-20 items-center justify-center rounded-full border border-gold/30 text-gold">
                  <ShoppingBag size={30} strokeWidth={1.2} />
                </span>
                <p className="heading mt-7 text-2xl">Your bag is empty</p>
                <p className="mt-3 max-w-xs text-sm text-mist">Discover a timepiece that suits your wrist and your story.</p>
                <button type="button" className="btn btn-primary mt-8" onClick={browse}>Explore Collection</button>
              </div>
            ) : (
              <>
                <ul className="flex-1 divide-y divide-white/10 overflow-y-auto px-6">
                  <AnimatePresence initial={false}>
                    {lines.map((l) => (
                      <motion.li
                        key={l.key}
                        layout
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.35 }}
                        className="overflow-hidden"
                      >
                        <div className="flex gap-4 py-5">
                          <div className="h-28 w-[5.25rem] shrink-0 overflow-hidden bg-charcoal">
                            <ProductImage product={l.product} imgClassName="h-full w-full object-cover" />
                          </div>
                          <div className="flex min-w-0 flex-1 flex-col">
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <p className="font-serif text-xl leading-tight">{l.product.name}</p>
                                {l.variant && <p className="mt-0.5 text-xs uppercase tracking-[0.18em] text-mist">{l.variant}</p>}
                              </div>
                              <button
                                type="button"
                                aria-label={`Remove ${l.product.name}`}
                                onClick={() => removeItem(l.key)}
                                className="-m-2 flex h-11 w-11 items-center justify-center text-mist transition-colors hover:text-gold"
                              >
                                <Trash2 size={17} />
                              </button>
                            </div>
                            <div className="mt-auto flex items-center justify-between">
                              <div className="flex items-center border border-white/15">
                                <button
                                  type="button"
                                  aria-label={`Decrease quantity of ${l.product.name}`}
                                  className="icon-btn h-10 w-10"
                                  onClick={() => setQty(l.key, l.qty - 1)}
                                >
                                  <Minus size={15} />
                                </button>
                                <span className="w-8 text-center text-sm tabular-nums" aria-live="polite">{l.qty}</span>
                                <button
                                  type="button"
                                  aria-label={`Increase quantity of ${l.product.name}`}
                                  className="icon-btn h-10 w-10"
                                  disabled={l.qty >= maxQty}
                                  onClick={() => setQty(l.key, l.qty + 1)}
                                >
                                  <Plus size={15} />
                                </button>
                              </div>
                              <p className="font-serif text-lg text-champagne">{formatPrice(l.product.price * l.qty)}</p>
                            </div>
                          </div>
                        </div>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>

                <footer className="border-t border-white/10 bg-charcoal/60 px-6 py-6">
                  <div className="flex items-baseline justify-between">
                    <span className="text-xs uppercase tracking-[0.25em] text-mist">Subtotal</span>
                    <span className="font-serif text-3xl text-white">{formatPrice(subtotal)}</span>
                  </div>
                  <p className="mt-2 text-xs text-mist">Shipping and taxes would be calculated at checkout.</p>
                  <button type="button" className="btn btn-primary mt-5 w-full" onClick={() => startCheckout(lines, true)}>
                    Checkout
                  </button>
                  <button type="button" className="btn btn-outline mt-3 w-full" onClick={closeCart}>
                    Continue Shopping
                  </button>
                </footer>
              </>
            )}
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
}
