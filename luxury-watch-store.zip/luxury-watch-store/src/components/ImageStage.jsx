import { useEffect, useRef } from 'react';
import { motion, useMotionValue, useReducedMotion, useSpring } from 'motion/react';
import ProductImage from './ProductImage.jsx';
import { clamp } from '../utils/format.js';

const edgeFade = 'radial-gradient(ellipse 72% 72% at 50% 50%, #000 58%, transparent 100%)';

/**
 * Photo-based product viewer. It does NOT fake a 360° spin: a single photograph
 * is shown with zoom, pan, a subtle perspective tilt and ambient light.
 * Swap it for <ModelStage/> by setting `model3D` on the product.
 */
export default function ImageStage({ product, zoom, motionOn, resetKey }) {
  const reduced = useReducedMotion();
  const ref = useRef(null);
  const drag = useRef(null);

  const tiltX = useMotionValue(0);
  const tiltY = useMotionValue(0);
  const panX = useMotionValue(0);
  const panY = useMotionValue(0);
  const scale = useMotionValue(1);

  const sTiltX = useSpring(tiltX, { stiffness: 90, damping: 18 });
  const sTiltY = useSpring(tiltY, { stiffness: 90, damping: 18 });
  const sPanX = useSpring(panX, { stiffness: 220, damping: 30 });
  const sPanY = useSpring(panY, { stiffness: 220, damping: 30 });
  const sScale = useSpring(scale, { stiffness: 140, damping: 24 });

  useEffect(() => {
    scale.set(zoom);
    if (zoom <= 1) {
      panX.set(0);
      panY.set(0);
    }
  }, [zoom, scale, panX, panY]);

  useEffect(() => {
    tiltX.set(0);
    tiltY.set(0);
    panX.set(0);
    panY.set(0);
    scale.set(1);
  }, [resetKey, tiltX, tiltY, panX, panY, scale]);

  const onPointerDown = (e) => {
    drag.current = { x: e.clientX, y: e.clientY, px: panX.get(), py: panY.get() };
    e.currentTarget.setPointerCapture?.(e.pointerId);
  };

  const onPointerMove = (e) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    if (drag.current && zoom > 1) {
      const limit = (zoom - 1) * Math.min(r.width, r.height) * 0.5;
      panX.set(clamp(drag.current.px + (e.clientX - drag.current.x), -limit, limit));
      panY.set(clamp(drag.current.py + (e.clientY - drag.current.y), -limit, limit));
      return;
    }
    if (reduced) return;
    if (e.pointerType === 'mouse' || drag.current) {
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      tiltY.set(px * 14);
      tiltX.set(-py * 10);
    }
  };

  const endDrag = (e) => {
    drag.current = null;
    if (e.pointerType !== 'mouse') {
      tiltX.set(0);
      tiltY.set(0);
    }
  };

  const onLeave = () => {
    drag.current = null;
    tiltX.set(0);
    tiltY.set(0);
  };

  const animateAmbient = motionOn && !reduced;

  return (
    <div
      ref={ref}
      className={`relative flex h-full w-full select-none items-center justify-center overflow-hidden ${
        zoom > 1 ? 'cursor-grab active:cursor-grabbing' : 'cursor-crosshair'
      }`}
      style={{ perspective: 1200, touchAction: zoom > 1 ? 'none' : 'pan-y' }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      onPointerLeave={onLeave}
    >
      {/* soft spotlight */}
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 46%, rgba(232,214,163,0.22) 0%, rgba(212,175,55,0.07) 32%, transparent 62%)',
        }}
        animate={animateAmbient ? { opacity: [0.75, 1, 0.75] } : { opacity: 0.9 }}
        transition={{ duration: 7, repeat: animateAmbient ? Infinity : 0, ease: 'easeInOut' }}
      />

      <motion.div
        className="relative aspect-[3/4] h-[88%] max-w-[94%]"
        style={{ scale: sScale, x: sPanX, y: sPanY, rotateX: sTiltX, rotateY: sTiltY }}
      >
        <motion.div
          className="relative h-full w-full"
          animate={animateAmbient ? { y: [0, -10, 0] } : { y: 0 }}
          transition={{ duration: 7, repeat: animateAmbient ? Infinity : 0, ease: 'easeInOut' }}
          style={{ WebkitMaskImage: edgeFade, maskImage: edgeFade }}
        >
          <ProductImage product={product} eager imgClassName="h-full w-full object-contain" />
          {animateAmbient && (
            <motion.div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0"
              style={{
                background: 'linear-gradient(105deg, transparent 42%, rgba(255,255,255,0.08) 50%, transparent 58%)',
              }}
              initial={{ x: '-110%' }}
              animate={{ x: '110%' }}
              transition={{ duration: 3.2, repeat: Infinity, repeatDelay: 5, ease: 'easeInOut' }}
            />
          )}
        </motion.div>
      </motion.div>
    </div>
  );
}
