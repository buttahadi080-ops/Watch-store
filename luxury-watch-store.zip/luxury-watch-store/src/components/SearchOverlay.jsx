import { useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Search, X } from 'lucide-react';
import ProductImage from './ProductImage.jsx';
import { products } from '../data/products.js';
import { formatPrice } from '../utils/format.js';
import { useDialog } from '../hooks/useDialog.js';
import { useStoreUI } from '../context/StoreUIContext.jsx';

export default function SearchOverlay() {
  const { searchOpen, closeSearch, openViewer } = useStoreUI();
  const [query, setQuery] = useState('');
  const ref = useRef(null);
  useDialog(searchOpen, closeSearch, ref);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products;
    return products.filter((p) => `${p.name} ${p.description}`.toLowerCase().includes(q));
  }, [query]);

  const choose = (id) => {
    closeSearch();
    setQuery('');
    openViewer(id);
  };

  return (
    <AnimatePresence>
      {searchOpen && (
        <motion.div
          ref={ref}
          role="dialog"
          aria-modal="true"
          aria-label="Search"
          tabIndex={-1}
          className="fixed inset-0 z-[65] bg-ink/95 backdrop-blur-md outline-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="container-x max-w-3xl pt-6 sm:pt-16">
            <div className="flex items-center gap-3 border-b border-white/20 pb-3 focus-within:border-gold">
              <Search size={20} className="text-gold" aria-hidden="true" />
              <label htmlFor="site-search" className="sr-only">Search watches</label>
              <input
                id="site-search"
                data-autofocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search the collection"
                autoComplete="off"
                className="min-w-0 flex-1 bg-transparent py-2 font-serif text-2xl text-white placeholder:text-white/30 focus:outline-none sm:text-3xl"
              />
              <button type="button" className="icon-btn" aria-label="Close search" onClick={closeSearch}>
                <X size={22} />
              </button>
            </div>

            <ul className="mt-6 space-y-2" aria-live="polite">
              {results.map((p) => (
                <li key={p.id}>
                  <button
                    type="button"
                    onClick={() => choose(p.id)}
                    className="group flex w-full items-center gap-4 border border-transparent p-2 text-left transition-colors hover:border-gold/40 hover:bg-white/[0.03]"
                  >
                    <span className="block h-20 w-[3.75rem] shrink-0 overflow-hidden bg-charcoal">
                      <ProductImage product={p} imgClassName="h-full w-full object-cover" />
                    </span>
                    <span className="flex-1">
                      <span className="block font-serif text-xl text-white group-hover:text-champagne">{p.name}</span>
                      <span className="line-clamp-1 block text-sm text-mist">{p.description}</span>
                    </span>
                    <span className="font-serif text-lg text-champagne">{formatPrice(p.price)}</span>
                  </button>
                </li>
              ))}
              {results.length === 0 && <li className="py-8 text-center text-mist">No watches match “{query}”.</li>}
            </ul>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
