import { Suspense, useEffect, useMemo, useRef } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import { ContactShadows, Environment, Html, Lightformer, OrbitControls, useGLTF } from '@react-three/drei';
import { useReducedMotion } from 'motion/react';
import * as THREE from 'three';

const BASE_DISTANCE = 4.6;

/** Centres the model and scales it to a consistent size regardless of how it was exported. */
function Model({ url }) {
  const { scene } = useGLTF(url);
  const object = useMemo(() => {
    const clone = scene.clone(true);
    const box = new THREE.Box3().setFromObject(clone);
    const size = box.getSize(new THREE.Vector3());
    const center = box.getCenter(new THREE.Vector3());
    clone.position.sub(center);
    const group = new THREE.Group();
    group.add(clone);
    group.scale.setScalar(2.2 / Math.max(size.x, size.y, size.z || 1));
    return group;
  }, [scene]);
  return <primitive object={object} />;
}

/** Connects the shared zoom / reset controls to the orbit camera. */
function Rig({ zoom, resetKey, controlsRef }) {
  const camera = useThree((s) => s.camera);

  useEffect(() => {
    controlsRef.current?.saveState();
  }, [controlsRef]);

  useEffect(() => {
    const c = controlsRef.current;
    if (!c) return;
    const dir = camera.position.clone().sub(c.target).normalize();
    camera.position.copy(c.target).addScaledVector(dir, BASE_DISTANCE / zoom);
    c.update();
  }, [zoom, camera, controlsRef]);

  useEffect(() => {
    controlsRef.current?.reset();
  }, [resetKey, controlsRef]);

  return null;
}

/**
 * Real 3D viewer (React Three Fiber). Rendered only when `product.model3D`
 * points at a real .glb/.gltf file. Auto-rotates slowly; drag to rotate.
 */
export default function ModelStage({ product, zoom, motionOn, resetKey }) {
  const reduced = useReducedMotion();
  const controlsRef = useRef(null);

  return (
    <div className="h-full w-full cursor-grab active:cursor-grabbing" style={{ touchAction: 'pan-y' }}>
      <Canvas
        dpr={[1, 2]}
        camera={{ position: [0, 0.35, BASE_DISTANCE], fov: 32 }}
        gl={{ antialias: true, powerPreference: 'high-performance' }}
        aria-label={`Interactive 3D model of ${product.name}`}
      >
        <ambientLight intensity={0.35} />
        <directionalLight position={[4, 6, 5]} intensity={1.4} />
        <Suspense
          fallback={
            <Html center>
              <span className="whitespace-nowrap text-xs uppercase tracking-[0.3em] text-champagne">Loading model…</span>
            </Html>
          }
        >
          <Model url={product.model3D} />
          <ContactShadows position={[0, -1.3, 0]} opacity={0.5} blur={2.6} far={3} scale={8} />
          <Environment resolution={256}>
            <group rotation={[-Math.PI / 3, 0, 1]}>
              <Lightformer form="rect" intensity={4} position={[0, 5, -9]} scale={[10, 10, 1]} />
              <Lightformer form="rect" intensity={2} position={[-5, 1, -1]} scale={[10, 2, 1]} />
              <Lightformer form="rect" intensity={2} position={[10, 1, 0]} scale={[20, 2, 1]} />
              <Lightformer form="ring" color="#E8D6A3" intensity={3} position={[10, 5, 0]} scale={4} />
            </group>
          </Environment>
        </Suspense>
        <OrbitControls
          ref={controlsRef}
          makeDefault
          enablePan={false}
          enableDamping
          minDistance={1.8}
          maxDistance={8}
          autoRotate={motionOn && !reduced}
          autoRotateSpeed={0.8}
        />
        <Rig zoom={zoom} resetKey={resetKey} controlsRef={controlsRef} />
      </Canvas>
    </div>
  );
}
