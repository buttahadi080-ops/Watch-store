import { motion } from 'motion/react';

/** Scroll-triggered fade + slide-up. Reduced-motion is handled globally by <MotionConfig>. */
export default function Reveal({ children, className = '', delay = 0, y = 28, as = 'div' }) {
  const Tag = motion[as] ?? motion.div;
  return (
    <Tag
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.9, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </Tag>
  );
}
