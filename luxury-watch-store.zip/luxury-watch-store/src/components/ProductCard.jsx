import ProductImage from './ProductImage.jsx';
import Reveal from './Reveal.jsx';
import { formatPrice } from '../utils/format.js';
import { useCart } from '../context/CartContext.jsx';
import { useStoreUI } from '../context/StoreUIContext.jsx';

export default function ProductCard({ product, index = 0 }) {
  const { addItem } = useCart();
  const { openViewer, openCart } = useStoreUI();

  const trackPointer = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    e.currentTarget.style.setProperty('--mx', `${e.clientX - r.left}px`);
    e.currentTarget.style.setProperty('--my', `${e.clientY - r.top}px`);
  };

  return (
    <Reveal delay={(index % 4) * 0.08} className="h-full">
      <article
        onPointerMove={trackPointer}
        className="group relative flex h-full flex-col border border-white/10 bg-charcoal/60 transition-[transform,border-color,box-shadow] duration-500 hover:-translate-y-1.5 hover:border-gold/60 hover:shadow-[0_30px_60px_-30px_rgba(212,175,55,0.35)]"
      >
        <span
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-10 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
          style={{
            background:
              'radial-gradient(320px circle at var(--mx, 50%) var(--my, 50%), rgba(212,175,55,0.12), transparent 60%)',
          }}
        />

        <button
          type="button"
          onClick={() => openViewer(product.id)}
          aria-label={`View ${product.name} in detail`}
          className="relative block aspect-[3/4] w-full cursor-zoom-in overflow-hidden bg-ink"
        >
          <ProductImage
            product={product}
            imgClassName="h-full w-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.06]"
          />
          <span className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-charcoal/80 to-transparent" aria-hidden="true" />
        </button>

        <div className="flex flex-1 flex-col p-5 sm:p-6">
          <div className="flex items-baseline justify-between gap-3">
            <h3 className="font-serif text-2xl text-white transition-colors duration-500 group-hover:text-champagne">
              {product.name}
            </h3>
            <p className="font-serif text-xl text-champagne">{formatPrice(product.price)}</p>
          </div>
          <div className="mt-3 h-px w-8 bg-gold transition-all duration-700 group-hover:w-20" aria-hidden="true" />
          <p className="mt-4 line-clamp-3 flex-1 text-sm leading-6 text-mist">{product.description}</p>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <button type="button" className="btn btn-outline !px-3" onClick={() => openViewer(product.id)}>
              View Details
            </button>
            <button
              type="button"
              className="btn btn-primary !px-3"
              onClick={() => {
                addItem(product.id);
                openCart();
              }}
            >
              Add to Cart
            </button>
          </div>
        </div>
      </article>
    </Reveal>
  );
}
