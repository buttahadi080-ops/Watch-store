import { useEffect } from 'react';
import { motion, useMotionValue, useReducedMotion, useSpring, useTransform } from 'motion/react';
import { ChevronDown } from 'lucide-react';
import ProductImage from './ProductImage.jsx';
import { BRAND } from '../config/brand.js';
import { getProductById, products } from '../data/products.js';
import { useGoToSection } from '../hooks/useGoToSection.js';

const ease = [0.22, 1, 0.36, 1];
const fade = (delay) => ({
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 1, delay, ease },
});
const edgeFade = 'radial-gradient(ellipse 70% 72% at 50% 50%, #000 52%, transparent 100%)';

export default function Hero() {
  const goTo = useGoToSection();
  const reduced = useReducedMotion();
  const product = getProductById(BRAND.heroProductId) ?? products[0];

  // Gentle mouse parallax (desktop pointers only).
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const sx = useSpring(mx, { stiffness: 50, damping: 20 });
  const sy = useSpring(my, { stiffness: 50, damping: 20 });
  const lightX = useTransform(sx, (v) => v * -0.7);
  const lightY = useTransform(sy, (v) => v * -0.7);

  useEffect(() => {
    if (reduced || !window.matchMedia('(pointer: fine)').matches) return undefined;
    const onMove = (e) => {
      mx.set((e.clientX / window.innerWidth - 0.5) * 36);
      my.set((e.clientY / window.innerHeight - 0.5) * 24);
    };
    window.addEventListener('pointermove', onMove, { passive: true });
    return () => window.removeEventListener('pointermove', onMove);
  }, [reduced, mx, my]);

  return (
    <section id="home" className="relative -mt-[72px] flex min-h-[100dvh] items-center overflow-hidden pt-[72px]">
      {/* atmosphere */}
      <div aria-hidden="true" className="absolute inset-0 bg-[radial-gradient(ellipse_at_75%_45%,#1d1a12_0%,#0b0b0b_62%)]" />
      <motion.div
        aria-hidden="true"
        className="absolute -left-40 top-10 h-[34rem] w-[34rem] rounded-full bg-gold/10 blur-[120px]"
        animate={reduced ? undefined : { x: [0, 60, 0], y: [0, 30, 0], opacity: [0.5, 0.85, 0.5] }}
        transition={{ duration: 16, repeat: Infinity, ease: 'easeInOut' }}
      />
      <div aria-hidden="true" className="absolute inset-y-0 left-6 hidden w-px bg-gradient-to-b from-transparent via-gold/30 to-transparent lg:block" />
      <div aria-hidden="true" className="absolute inset-y-0 right-6 hidden w-px bg-gradient-to-b from-transparent via-gold/20 to-transparent lg:block" />

      <div className="container-x relative grid items-center gap-6 py-10 lg:grid-cols-2 lg:gap-10">
        {/* copy */}
        <div className="order-2 text-center lg:order-1 lg:text-left">
          <motion.span className="eyebrow" {...fade(0.2)}>New collection</motion.span>

          <h1 className="heading mt-6 text-[2.5rem] leading-[1.04] sm:text-6xl xl:text-[4.6rem]">
            <span className="block overflow-hidden pb-1">
              <motion.span
                className="block"
                initial={{ y: '110%' }}
                animate={{ y: 0 }}
                transition={{ duration: 1.1, delay: 0.35, ease }}
              >
                Timeless elegance.
              </motion.span>
            </span>
            <span className="block overflow-hidden pb-1">
              <motion.span
                className="gold-text block"
                initial={{ y: '110%' }}
                animate={{ y: 0 }}
                transition={{ duration: 1.1, delay: 0.5, ease }}
              >
                Unmatched presence.
              </motion.span>
            </span>
          </h1>

          <motion.p className="mx-auto mt-7 max-w-md text-base leading-8 text-white/70 lg:mx-0" {...fade(0.8)}>
            Discover the art of precision, crafted for those who value every moment.
          </motion.p>

          <motion.div className="mt-10 flex flex-col items-stretch gap-4 sm:flex-row sm:justify-center lg:justify-start" {...fade(1)}>
            <button type="button" className="btn btn-primary" onClick={() => goTo('collection')}>Explore Collection</button>
            <button type="button" className="btn btn-outline" onClick={() => goTo('story')}>Discover Our Story</button>
          </motion.div>
        </div>

        {/* watch */}
        <div className="relative order-1 flex items-center justify-center lg:order-2">
          <motion.div
            aria-hidden="true"
            className="absolute h-[88%] w-[88%] max-w-[34rem] rounded-full"
            style={{
              x: lightX,
              y: lightY,
              background: 'radial-gradient(circle, rgba(232,214,163,0.28) 0%, rgba(212,175,55,0.08) 40%, transparent 68%)',
            }}
          />
          <motion.div
            aria-hidden="true"
            className="absolute h-[70%] w-[70%] max-w-[26rem] rounded-full border border-gold/20"
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.6, delay: 0.3, ease }}
          />

          <motion.div
            className="relative aspect-[3/4] w-[min(72vw,22rem)] sm:w-[26rem] lg:w-[min(34vw,30rem)]"
            style={{ x: sx, y: sy }}
          >
            <motion.div
              className="h-full w-full"
              initial={{ opacity: 0, scale: 1.1, y: 50, filter: 'blur(14px)' }}
              animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
              transition={{ duration: 1.8, delay: 0.25, ease }}
            >
              <motion.div
                className="h-full w-full"
                animate={reduced ? undefined : { y: [0, -12, 0] }}
                transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut', delay: 2 }}
                style={{ WebkitMaskImage: edgeFade, maskImage: edgeFade }}
              >
                <ProductImage product={product} eager imgClassName="h-full w-full object-contain" />
              </motion.div>
            </motion.div>
          </motion.div>
        </div>
      </div>

      <motion.button
        type="button"
        onClick={() => goTo('collection')}
        aria-label="Scroll to the collection"
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-[0.62rem] uppercase tracking-[0.35em] text-mist transition-colors hover:text-gold sm:flex"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 1 }}
      >
        Scroll
        <motion.span animate={reduced ? undefined : { y: [0, 6, 0] }} transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}>
          <ChevronDown size={18} />
        </motion.span>
      </motion.button>
    </section>
  );
}
