import { useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { X } from 'lucide-react';
import ProductShowcase from './ProductShowcase.jsx';
import { getProductById } from '../data/products.js';
import { useDialog } from '../hooks/useDialog.js';
import { useStoreUI } from '../context/StoreUIContext.jsx';

const slide = {
  enter: (d) => ({ opacity: 0, x: 48 * d }),
  center: { opacity: 1, x: 0 },
  exit: (d) => ({ opacity: 0, x: -48 * d }),
};

/** Immersive full-screen product viewer, opened from any product card. */
export default function ProductViewer() {
  const { viewerId, viewerDir, closeViewer, stepViewer, cartOpen, checkout } = useStoreUI();
  const product = getProductById(viewerId);
  const ref = useRef(null);
  const active = Boolean(product) && !cartOpen && !checkout;

  useDialog(active, closeViewer, ref);

  useEffect(() => {
    if (!active) return undefined;
    const onKey = (e) => {
      if (e.key === 'ArrowRight') stepViewer(1);
      if (e.key === 'ArrowLeft') stepViewer(-1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [active, stepViewer]);

  return (
    <AnimatePresence>
      {product && (
        <motion.div
          key="viewer"
          ref={ref}
          role="dialog"
          aria-modal="true"
          aria-label={`${product.name} — product viewer`}
              tabIndex={-1}
          className="fixed inset-0 z-[70] overflow-y-auto bg-ink outline-none"
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.97 }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        >
          <button
            type="button"
            onClick={closeViewer}
            aria-label="Close viewer"
            data-autofocus
            className="glass fixed right-3 top-3 z-20 flex h-11 w-11 items-center justify-center rounded-full text-white transition-colors hover:border-gold hover:text-gold sm:right-5 sm:top-5"
          >
            <X size={20} />
          </button>

          <AnimatePresence mode="wait" custom={viewerDir} initial={false}>
            <motion.div
              key={product.id}
              custom={viewerDir}
              variants={slide}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            >
              <ProductShowcase
                product={product}
                onPrev={() => stepViewer(-1)}
                onNext={() => stepViewer(1)}
                onNavigate={closeViewer}
                layout="modal"
              />
            </motion.div>
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
