import { Gem, Sparkles, Watch } from 'lucide-react';
import Reveal from './Reveal.jsx';

const FEATURES = [
  {
    icon: Gem,
    title: 'Timeless Design',
    text: 'Classic proportions and restrained details that stay relevant long after trends have moved on.',
  },
  {
    icon: Watch,
    title: 'Everyday Versatility',
    text: 'A look that moves easily from the office to the weekend, from formal evenings to casual days.',
  },
  {
    icon: Sparkles,
    title: 'Confidence in Every Moment',
    text: 'A watch with real presence — one that quietly completes the way you carry yourself.',
  },
];

export default function Features() {
  return (
    <section className="py-24 sm:py-32" aria-labelledby="features-title">
      <div className="container-x">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Why choose us</span>
          <h2 id="features-title" className="heading mt-5 text-4xl sm:text-5xl">Made to be worn, every day</h2>
        </Reveal>
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {FEATURES.map(({ icon: Icon, title, text }, i) => (
            <Reveal key={title} delay={i * 0.1}>
              <div className="group h-full border border-white/10 bg-charcoal/50 p-8 transition-colors duration-500 hover:border-gold/50 sm:p-10">
                <span className="flex h-14 w-14 items-center justify-center rounded-full border border-gold/40 text-gold transition-colors duration-500 group-hover:bg-gold group-hover:text-ink">
                  <Icon size={24} strokeWidth={1.3} />
                </span>
                <h3 className="heading mt-7 text-2xl">{title}</h3>
                <div className="mt-4 h-px w-10 bg-gold transition-all duration-700 group-hover:w-24" aria-hidden="true" />
                <p className="mt-5 leading-7 text-mist">{text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
