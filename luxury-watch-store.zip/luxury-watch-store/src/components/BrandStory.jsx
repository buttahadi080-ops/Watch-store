import Reveal from './Reveal.jsx';
import ProductImage from './ProductImage.jsx';
import { getProductById } from '../data/products.js';

export default function BrandStory() {
  const product = getProductById(3);
  return (
    <section id="story" className="relative bg-charcoal py-24 sm:py-32" aria-labelledby="story-title">
      <div className="container-x grid items-center gap-14 lg:grid-cols-2 lg:gap-24">
        <Reveal className="relative mx-auto w-full max-w-md lg:order-2">
          <div className="absolute -bottom-4 -right-4 h-full w-full border border-gold/40" aria-hidden="true" />
          <div className="relative aspect-[3/4] overflow-hidden bg-ink">
            <ProductImage product={product} imgClassName="h-full w-full object-cover" />
          </div>
        </Reveal>

        <div className="lg:order-1">
          <Reveal>
            <span className="eyebrow">Our Story</span>
            <h2 id="story-title" className="heading mt-5 text-4xl sm:text-5xl">More than a watch. A statement.</h2>
          </Reveal>
          <Reveal delay={0.1} className="mt-8 space-y-5 text-[0.98rem] leading-8 text-white/70">
            <p>
              A watch is the one piece a man wears every day — and the one that says the most without a word. We
              design ours with that in mind: clean proportions, considered details and a presence that feels
              effortless.
            </p>
            <p>
              Every line is chosen with intention. Polished and brushed surfaces catch the light, dials are kept
              uncluttered, and nothing is added unless it earns its place.
            </p>
            <p>
              Because true style is not loud. It is confident, composed and timeless — and it looks just as right
              at a morning meeting as it does at dinner.
            </p>
          </Reveal>
          <Reveal delay={0.2} className="mt-10 flex items-center gap-5">
            <span className="h-px w-16 bg-gold" aria-hidden="true" />
            <span className="font-serif text-xl italic text-champagne">Design that outlasts the moment.</span>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
