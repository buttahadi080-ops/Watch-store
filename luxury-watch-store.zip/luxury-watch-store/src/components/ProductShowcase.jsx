import { lazy, Suspense, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight, ChevronLeft, ChevronRight, Pause, Play, RotateCcw, ZoomIn, ZoomOut,
} from 'lucide-react';
import ImageStage from './ImageStage.jsx';
import ErrorBoundary from './ErrorBoundary.jsx';
import { products } from '../data/products.js';
import { formatPrice } from '../utils/format.js';
import { hasWebGL } from '../utils/webgl.js';
import { makeKey } from '../context/cartReducer.js';
import { useCart } from '../context/CartContext.jsx';
import { useStoreUI } from '../context/StoreUIContext.jsx';

// three.js / R3F are only downloaded when a product really has a 3D model.
const ModelStage = lazy(() => import('./ModelStage.jsx'));

const MIN_ZOOM = 1;
const MAX_ZOOM = 3;

function ControlButton({ label, onClick, disabled, children }) {
  return (
    <button type="button" className="icon-btn" aria-label={label} title={label} onClick={onClick} disabled={disabled}>
      {children}
    </button>
  );
}

/**
 * Large product view + controls + product information.
 * Used by the modal <ProductViewer/> and by the /product/:slug page.
 * Remount with a new `key` when the product changes.
 */
export default function ProductShowcase({ product, onPrev, onNext, onNavigate, layout = 'modal' }) {
  const { addItem } = useCart();
  const { openCart, startCheckout } = useStoreUI();
  const [zoom, setZoom] = useState(1);
  const [motionOn, setMotionOn] = useState(true);
  const [resetKey, setResetKey] = useState(0);
  const [variant, setVariant] = useState(product.variants?.[0] ?? null);
  const [webgl] = useState(() => hasWebGL());

  const use3D = Boolean(product.model3D) && webgl;
  const index = products.findIndex((p) => p.id === product.id);

  const zoomIn = () => setZoom((z) => Math.min(MAX_ZOOM, +(z + 0.5).toFixed(2)));
  const zoomOut = () => setZoom((z) => Math.max(MIN_ZOOM, +(z - 0.5).toFixed(2)));
  const reset = () => {
    setZoom(1);
    setResetKey((k) => k + 1);
  };

  const stageProps = { product, zoom, motionOn, resetKey };
  const stage = use3D ? (
    <ErrorBoundary fallback={<ImageStage {...stageProps} />}>
      <Suspense
        fallback={
          <div className="flex h-full items-center justify-center text-xs uppercase tracking-[0.3em] text-champagne">
            Loading viewer…
          </div>
        }
      >
        <ModelStage {...stageProps} />
      </Suspense>
    </ErrorBoundary>
  ) : (
    <ImageStage {...stageProps} />
  );

  const isModal = layout === 'modal';
  const motionLabel = use3D
    ? motionOn ? 'Pause auto-rotation' : 'Resume auto-rotation'
    : motionOn ? 'Pause ambient motion' : 'Resume ambient motion';

  return (
    <div className={isModal ? 'grid min-h-dvh lg:h-dvh lg:grid-cols-[1.15fr_0.85fr]' : 'grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:gap-12'}>
      {/* ───────── stage ───────── */}
      <div
        className={`relative overflow-hidden bg-[radial-gradient(ellipse_at_center,#1b1b1b_0%,#0b0b0b_75%)] ${
          isModal ? 'h-[62dvh] lg:h-dvh' : 'h-[68dvh] border border-white/10'
        }`}
      >
        {stage}

        <span className="pointer-events-none absolute left-4 top-4 text-[0.7rem] tracking-[0.3em] text-mist sm:left-6 sm:top-6">
          {String(index + 1).padStart(2, '0')} / {String(products.length).padStart(2, '0')}
        </span>

        <button
          type="button"
          onClick={onPrev}
          aria-label="Previous product"
          className="glass absolute left-2 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full text-white transition-colors hover:border-gold hover:text-gold sm:left-4"
        >
          <ChevronLeft size={20} />
        </button>
        <button
          type="button"
          onClick={onNext}
          aria-label="Next product"
          className="glass absolute right-2 top-1/2 flex h-11 w-11 -translate-y-1/2 items-center justify-center rounded-full text-white transition-colors hover:border-gold hover:text-gold sm:right-4"
        >
          <ChevronRight size={20} />
        </button>

        <div className="absolute inset-x-0 bottom-4 flex flex-col items-center gap-2 px-3">
          <div className="glass flex items-center rounded-full px-1.5" role="group" aria-label="Viewer controls">
            <ControlButton label="Zoom out" onClick={zoomOut} disabled={zoom <= MIN_ZOOM}><ZoomOut size={19} /></ControlButton>
            <ControlButton label="Zoom in" onClick={zoomIn} disabled={zoom >= MAX_ZOOM}><ZoomIn size={19} /></ControlButton>
            <ControlButton label="Reset view" onClick={reset}><RotateCcw size={18} /></ControlButton>
            <ControlButton label={motionLabel} onClick={() => setMotionOn((v) => !v)}>
              {motionOn ? <Pause size={18} /> : <Play size={18} />}
            </ControlButton>
          </div>
          <p className="text-center text-[0.68rem] uppercase tracking-[0.22em] text-mist">
            {use3D ? 'Drag to rotate · use buttons to zoom' : zoom > 1 ? 'Drag to move the photo' : 'Move over the photo to tilt · zoom to inspect'}
          </p>
        </div>
      </div>

      {/* ───────── information ───────── */}
      <div className={isModal ? 'flex flex-col justify-center px-6 pb-16 pt-8 sm:px-10 lg:overflow-y-auto lg:px-14 lg:py-16' : 'flex flex-col justify-center py-4'}>
        <span className="eyebrow">The Collection</span>
        <h2 className="heading mt-5 text-4xl sm:text-5xl">{product.name}</h2>
        <p className="mt-4 font-serif text-3xl text-champagne">{formatPrice(product.price)}</p>
        <div className="hairline my-7" />
        <p className="max-w-md text-[0.95rem] leading-7 text-white/75">{product.description}</p>

        {product.details?.length > 0 && (
          <ul className="mt-6 space-y-2 text-sm text-mist">
            {product.details.map((d) => (
              <li key={d} className="flex items-center gap-3">
                <span className="h-px w-5 bg-gold" aria-hidden="true" />
                {d}
              </li>
            ))}
          </ul>
        )}

        {product.variants?.length > 0 && (
          <fieldset className="mt-7">
            <legend className="mb-3 text-[0.7rem] uppercase tracking-[0.25em] text-mist">Variant</legend>
            <div className="flex flex-wrap gap-2">
              {product.variants.map((v) => (
                <button
                  key={v}
                  type="button"
                  aria-pressed={variant === v}
                  onClick={() => setVariant(v)}
                  className={`min-h-11 border px-4 text-xs uppercase tracking-[0.18em] transition-colors ${
                    variant === v ? 'border-gold bg-gold/10 text-champagne' : 'border-white/15 text-white/70 hover:border-white/40'
                  }`}
                >
                  {v}
                </button>
              ))}
            </div>
          </fieldset>
        )}

        <div className="mt-9 flex max-w-md flex-col gap-3">
          <button
            type="button"
            className="btn btn-primary w-full"
            onClick={() => {
              addItem(product.id, variant);
              openCart();
            }}
          >
            Add to Cart
          </button>
          <button
            type="button"
            className="btn btn-outline w-full"
            onClick={() =>
              startCheckout([{ key: makeKey(product.id, variant), id: product.id, variant, qty: 1, product }], false)
            }
          >
            Buy Now
          </button>
        </div>

        {isModal && (
          <Link
            to={`/product/${product.slug}`}
            onClick={onNavigate}
            className="mt-8 inline-flex items-center gap-2 self-start text-xs uppercase tracking-[0.22em] text-mist transition-colors hover:text-gold"
          >
            Open full page <ArrowRight size={14} />
          </Link>
        )}
      </div>
    </div>
  );
}
