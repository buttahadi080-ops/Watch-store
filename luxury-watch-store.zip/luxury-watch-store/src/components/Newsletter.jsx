import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import Reveal from './Reveal.jsx';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const ENDPOINT = import.meta.env.VITE_NEWSLETTER_ENDPOINT;

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState(null); // { type: 'error' | 'success' | 'demo', msg }
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    const value = email.trim();
    if (!EMAIL_RE.test(value)) {
      setStatus({ type: 'error', msg: 'Please enter a valid email address.' });
      return;
    }
    if (!ENDPOINT) {
      setStatus({
        type: 'demo',
        msg: 'Demo mode: that address looks valid, but no newsletter service is connected, so it was not saved.',
      });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: value }),
      });
      if (!res.ok) throw new Error('bad response');
      setStatus({ type: 'success', msg: 'Thank you — you are on the list.' });
      setEmail('');
    } catch {
      setStatus({ type: 'error', msg: 'Something went wrong. Please try again in a moment.' });
    } finally {
      setBusy(false);
    }
  };

  const tone = status?.type === 'error' ? 'text-red-300' : status?.type === 'success' ? 'text-emerald-300' : 'text-champagne';

  return (
    <section className="py-24 sm:py-28" aria-labelledby="newsletter-title">
      <div className="container-x">
        <Reveal className="relative mx-auto max-w-3xl border border-gold/30 px-6 py-14 text-center sm:px-14">
          <span className="eyebrow">Stay informed</span>
          <h2 id="newsletter-title" className="heading mt-5 text-3xl sm:text-4xl">Join the inner circle</h2>
          <p className="mx-auto mt-4 max-w-md text-mist">New releases and private announcements, delivered sparingly.</p>

          <form onSubmit={submit} noValidate className="mx-auto mt-9 flex max-w-lg flex-col gap-3 sm:flex-row">
            <label htmlFor="newsletter-email" className="sr-only">Email address</label>
            <input
              id="newsletter-email"
              type="email"
              inputMode="email"
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email address"
              aria-invalid={status?.type === 'error'}
              aria-describedby="newsletter-status"
              className="min-h-12 flex-1 border border-white/20 bg-transparent px-4 text-white placeholder:text-white/35 focus:border-gold focus:outline-none"
            />
            <button type="submit" className="btn btn-primary" disabled={busy}>
              {busy ? 'Sending…' : 'Subscribe'} <ArrowRight size={15} />
            </button>
          </form>
          <p id="newsletter-status" role="status" aria-live="polite" className={`mx-auto mt-4 min-h-[1.5rem] max-w-lg text-sm ${tone}`}>
            {status?.msg}
          </p>
        </Reveal>
      </div>
    </section>
  );
}
