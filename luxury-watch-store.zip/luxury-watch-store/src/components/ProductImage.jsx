import { useEffect, useState } from 'react';

/** Product photo with WebP source, lazy loading and a graceful missing-image fallback. */
export default function ProductImage({ product, eager = false, imgClassName = '', style }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [product.image]);

  if (failed) {
    return (
      <div
        role="img"
        aria-label={product.alt}
        className="flex h-full w-full items-center justify-center bg-charcoal px-4 text-center text-xs uppercase tracking-[0.25em] text-mist"
      >
        Image unavailable
      </div>
    );
  }

  return (
    <picture>
      {product.imageWebp && <source srcSet={product.imageWebp} type="image/webp" />}
      <img
        src={product.image}
        alt={product.alt}
        loading={eager ? 'eager' : 'lazy'}
        decoding="async"
        fetchPriority={eager ? 'high' : 'auto'}
        draggable={false}
        onError={() => setFailed(true)}
        className={imgClassName}
        style={style}
      />
    </picture>
  );
}
