import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Check, X } from 'lucide-react';
import ProductImage from './ProductImage.jsx';
import { formatPrice } from '../utils/format.js';
import { CHECKOUT_MODE, createCheckoutSession } from '../utils/checkout.js';
import { useCart } from '../context/CartContext.jsx';
import { useStoreUI } from '../context/StoreUIContext.jsx';
import { useDialog } from '../hooks/useDialog.js';

export default function CheckoutModal() {
  const { checkout, closeCheckout } = useStoreUI();
  const { clearCart } = useCart();
  const ref = useRef(null);
  const [stage, setStage] = useState('review'); // review | done
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useDialog(Boolean(checkout), closeCheckout, ref);

  useEffect(() => {
    if (checkout) {
      setStage('review');
      setBusy(false);
      setError('');
    }
  }, [checkout]);

  const lines = checkout?.lines ?? [];
  const subtotal = lines.reduce((s, l) => s + l.product.price * l.qty, 0);
  const live = CHECKOUT_MODE === 'live';

  const confirm = async () => {
    setBusy(true);
    setError('');
    try {
      const result = await createCheckoutSession(lines);
      if (result.mode === 'live') {
        window.location.assign(result.url);
        return;
      }
      if (checkout?.fromCart) clearCart();
      setStage('done');
    } catch {
      setError('We could not start checkout. Please try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <AnimatePresence>
      {checkout && (
        <div className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-6">
          <motion.div
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeCheckout}
            aria-hidden="true"
          />
          <motion.div
            ref={ref}
            role="dialog"
            aria-modal="true"
            aria-label="Checkout"
            tabIndex={-1}
            className="relative max-h-[92dvh] w-full max-w-lg overflow-y-auto border border-white/10 bg-ink p-6 outline-none sm:p-8"
            initial={{ opacity: 0, y: 40, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
          >
            <button type="button" className="icon-btn absolute right-2 top-2" aria-label="Close checkout" data-autofocus onClick={closeCheckout}>
              <X size={22} />
            </button>

            {stage === 'review' ? (
              <>
                <span className="eyebrow">{live ? 'Secure checkout' : 'Demo checkout'}</span>
                <h2 className="heading mt-4 text-3xl">Order summary</h2>

                {!live && (
                  <p className="mt-4 border border-gold/30 bg-gold/5 p-3 text-xs leading-5 text-champagne" role="note">
                    This is a demonstration. No payment gateway is connected, so nothing will be charged and no order will be placed.
                  </p>
                )}

                <ul className="mt-6 divide-y divide-white/10">
                  {lines.map((l) => (
                    <li key={l.key} className="flex items-center gap-4 py-4">
                      <div className="h-16 w-12 shrink-0 overflow-hidden bg-charcoal">
                        <ProductImage product={l.product} imgClassName="h-full w-full object-cover" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-serif text-lg leading-tight">{l.product.name}</p>
                        <p className="text-xs text-mist">Qty {l.qty}{l.variant ? ` · ${l.variant}` : ''}</p>
                      </div>
                      <p className="font-serif text-lg text-champagne">{formatPrice(l.product.price * l.qty)}</p>
                    </li>
                  ))}
                </ul>

                <div className="mt-2 flex items-baseline justify-between border-t border-white/10 pt-5">
                  <span className="text-xs uppercase tracking-[0.25em] text-mist">Subtotal</span>
                  <span className="font-serif text-3xl">{formatPrice(subtotal)}</span>
                </div>

                {error && <p role="alert" className="mt-4 text-sm text-red-300">{error}</p>}

                <button type="button" className="btn btn-primary mt-6 w-full" onClick={confirm} disabled={busy || lines.length === 0}>
                  {busy ? 'Please wait…' : live ? 'Continue to secure payment' : 'Complete demo order'}
                </button>
              </>
            ) : (
              <div className="py-6 text-center">
                <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold/50 text-gold">
                  <Check size={28} />
                </span>
                <h2 className="heading mt-6 text-3xl">Demo complete</h2>
                <p className="mx-auto mt-3 max-w-sm text-sm text-mist">
                  No payment was taken and no order was created. Connect a payment provider to turn this into real checkout.
                </p>
                <button type="button" className="btn btn-outline mt-7" onClick={closeCheckout}>Close</button>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
