import { Link } from 'react-router-dom';
import Logo from './Logo.jsx';
import { BRAND } from '../config/brand.js';
import { useGoToSection } from '../hooks/useGoToSection.js';

export default function Footer() {
  const goTo = useGoToSection();
  const year = new Date().getFullYear();
  const nav = [
    ['Home', 'home'],
    ['Collection', 'collection'],
    ['Our Story', 'story'],
  ];

  return (
    <footer id="contact" className="border-t border-white/10 bg-charcoal">
      <div className="container-x grid gap-12 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-6 max-w-sm text-sm leading-7 text-mist">{BRAND.footerDescription}</p>
        </div>

        <div>
          <h3 className="text-[0.7rem] font-medium uppercase tracking-[0.3em] text-gold">Explore</h3>
          <ul className="mt-5 space-y-3 text-sm">
            {nav.map(([label, id]) => (
              <li key={id}>
                <button type="button" onClick={() => goTo(id)} className="text-white/70 transition-colors hover:text-gold">
                  {label}
                </button>
              </li>
            ))}
            <li><Link to="/privacy" className="text-white/70 transition-colors hover:text-gold">Privacy Policy</Link></li>
            <li><Link to="/terms" className="text-white/70 transition-colors hover:text-gold">Terms &amp; Conditions</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-[0.7rem] font-medium uppercase tracking-[0.3em] text-gold">Contact</h3>
          <address className="mt-5 space-y-3 text-sm not-italic text-white/70">
            <p>{BRAND.contact.address}</p>
            <p><a href={`mailto:${BRAND.contact.email}`} className="transition-colors hover:text-gold">{BRAND.contact.email}</a></p>
            <p>{BRAND.contact.phone}</p>
          </address>
          <ul className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-xs uppercase tracking-[0.2em]">
            {BRAND.social.map((s) => (
              <li key={s.label}>
                <a href={s.href} target={s.href === '#' ? undefined : '_blank'} rel="noopener noreferrer" className="text-white/60 transition-colors hover:text-gold">
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="hairline" />
      <p className="container-x py-6 text-center text-xs tracking-wider text-mist">
        © {year} {BRAND.name}. All rights reserved.
      </p>
    </footer>
  );
}
