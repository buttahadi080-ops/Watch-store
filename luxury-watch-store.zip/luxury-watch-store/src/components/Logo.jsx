import { BRAND } from '../config/brand.js';

export default function Logo({ className = '' }) {
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <svg width="26" height="26" viewBox="0 0 32 32" fill="none" aria-hidden="true">
        <circle cx="16" cy="16" r="14" stroke="#D4AF37" strokeWidth="1.2" />
        <circle cx="16" cy="16" r="9.5" stroke="#E8D6A3" strokeOpacity=".5" strokeWidth=".8" />
        <path d="M16 7v9l5 3" stroke="#D4AF37" strokeWidth="1.4" strokeLinecap="round" />
      </svg>
      <span className="font-serif text-[1.3rem] font-medium tracking-[0.3em] text-white">{BRAND.name}</span>
    </span>
  );
}
