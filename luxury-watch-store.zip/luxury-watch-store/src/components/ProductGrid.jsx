import Reveal from './Reveal.jsx';
import ProductCard from './ProductCard.jsx';
import { products } from '../data/products.js';

export default function ProductGrid() {
  return (
    <section id="collection" className="relative py-24 sm:py-32" aria-labelledby="collection-title">
      <div className="container-x">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">The Collection</span>
          <h2 id="collection-title" className="heading mt-5 text-4xl sm:text-5xl">Four watches. One standard.</h2>
          <p className="mt-5 text-mist">
            Select any watch to see it larger, zoom in on the details and add it to your bag.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
          {products.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}
