import { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'motion/react';
import { useGoToSection } from '../hooks/useGoToSection.js';

export default function BrandBanner() {
  const ref = useRef(null);
  const goTo = useGoToSection();
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], ['-7%', '7%']);

  return (
    <section ref={ref} className="relative isolate flex min-h-[34rem] items-center overflow-hidden sm:min-h-[40rem]" aria-labelledby="banner-title">
      <motion.div className="absolute inset-x-0 -inset-y-[10%] -z-20" style={reduced ? undefined : { y }}>
        <picture className="block h-full w-full">
          <source srcSet="/images/banner.webp" type="image/webp" />
          <img
            src="/images/banner.jpg"
            alt="Stainless steel chronograph watch on dark stone, lit by a sweep of golden light"
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover object-[68%_center]"
          />
        </picture>
      </motion.div>
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-gradient-to-r from-ink via-ink/80 to-ink/10 sm:via-ink/55" />
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-gradient-to-t from-ink/70 via-transparent to-ink/40" />

      <div className="container-x py-20">
        <motion.div
          className="max-w-xl"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
        >
          <span className="eyebrow">The Statement Piece</span>
          <h2 id="banner-title" className="heading gold-text mt-6 text-4xl sm:text-6xl">
            Every second, well spent.
          </h2>
          <p className="mt-6 max-w-md text-white/75">
            Bold in form, calm in character. A watch for the moments that define you.
          </p>
          <button type="button" className="btn btn-outline mt-9" onClick={() => goTo('collection')}>
            Shop the Collection
          </button>
        </motion.div>
      </div>
    </section>
  );
}
