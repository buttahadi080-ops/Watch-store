import { Quote } from 'lucide-react';
import Reveal from './Reveal.jsx';
import { sampleTestimonials, testimonials } from '../data/testimonials.js';

export default function Testimonials() {
  const isSample = testimonials.length === 0;
  // Samples are visible only while developing; production builds show nothing until real reviews exist.
  const list = isSample ? (import.meta.env.DEV ? sampleTestimonials : []) : testimonials;
  if (list.length === 0) return null;

  return (
    <section className="bg-charcoal py-24 sm:py-32" aria-labelledby="testimonials-title">
      <div className="container-x">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="eyebrow">Customer words</span>
          <h2 id="testimonials-title" className="heading mt-5 text-4xl sm:text-5xl">Worn and trusted</h2>
          {isSample && (
            <p role="note" className="mx-auto mt-6 inline-block border border-gold/40 bg-gold/5 px-4 py-2 text-xs uppercase tracking-[0.18em] text-champagne">
              Development preview — sample placeholders, not real customer reviews
            </p>
          )}
        </Reveal>
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {list.map((t, i) => (
            <Reveal key={t.id} delay={i * 0.1}>
              <figure className="h-full border border-white/10 bg-ink p-8">
                <Quote size={26} className="text-gold" strokeWidth={1.2} aria-hidden="true" />
                <blockquote className="mt-5 font-serif text-xl leading-8 text-white/90">{t.quote}</blockquote>
                <figcaption className="mt-6 text-xs uppercase tracking-[0.22em] text-mist">
                  {t.name}{t.location ? ` · ${t.location}` : ''}
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
