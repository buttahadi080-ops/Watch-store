import { useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { Menu, Search, ShoppingBag, X } from 'lucide-react';
import Logo from './Logo.jsx';
import { useCart } from '../context/CartContext.jsx';
import { useStoreUI } from '../context/StoreUIContext.jsx';
import { useGoToSection } from '../hooks/useGoToSection.js';
import { useDialog } from '../hooks/useDialog.js';

const LINKS = [
  { label: 'Home', id: 'home' },
  { label: 'Collection', id: 'collection' },
  { label: 'Our Story', id: 'story' },
  { label: 'Contact', id: 'contact' },
];

export default function Navbar() {
  const { pathname } = useLocation();
  const isHome = pathname === '/';
  const { count } = useCart();
  const { openCart, openSearch } = useStoreUI();
  const goTo = useGoToSection();
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState('home');
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const closeMenu = () => setMenuOpen(false);

  useDialog(menuOpen, closeMenu, menuRef);

  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      setScrolled(window.scrollY > 40);
      if (!isHome) return;
      const probe = window.innerHeight * 0.35;
      let current = 'home';
      for (const { id } of LINKS) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top <= probe) current = id;
      }
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) current = 'contact';
      setActive(current);
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, [isHome]);

  const solid = scrolled || !isHome;

  const handleNav = (id) => {
    closeMenu();
    goTo(id);
  };

  return (
    <>
      <header
        className={`sticky top-0 z-40 h-[72px] transition-[background-color,border-color,backdrop-filter] duration-500 ${
          solid
            ? 'border-b border-white/10 bg-ink/90 backdrop-blur-md'
            : 'border-b border-transparent bg-transparent'
        }`}
      >
        <nav aria-label="Main" className="container-x flex h-full items-center justify-between">
          <Link to="/" aria-label="Home" onClick={() => isHome && goTo('home')}>
            <Logo />
          </Link>

          <ul className="hidden items-center gap-10 md:flex">
            {LINKS.map((l) => (
              <li key={l.id}>
                <button
                  type="button"
                  onClick={() => handleNav(l.id)}
                  aria-current={isHome && active === l.id ? 'true' : undefined}
                  className={`relative py-2 text-[0.72rem] font-medium uppercase tracking-[0.24em] transition-colors ${
                    isHome && active === l.id ? 'text-champagne' : 'text-white/75 hover:text-white'
                  }`}
                >
                  {l.label}
                  {isHome && active === l.id && (
                    <motion.span
                      layoutId="nav-underline"
                      className="absolute inset-x-0 -bottom-0.5 h-px bg-gold"
                      transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                    />
                  )}
                </button>
              </li>
            ))}
          </ul>

          <div className="flex items-center">
            <button type="button" className="icon-btn" aria-label="Search watches" onClick={openSearch}>
              <Search size={20} />
            </button>
            <button type="button" className="icon-btn relative" aria-label={`Open shopping bag, ${count} items`} onClick={openCart}>
              <ShoppingBag size={20} />
              <AnimatePresence>
                {count > 0 && (
                  <motion.span
                    key={count}
                    initial={{ scale: 0.4, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.4, opacity: 0 }}
                    className="absolute right-0.5 top-1 flex h-[1.1rem] min-w-[1.1rem] items-center justify-center rounded-full bg-gold px-1 text-[0.62rem] font-semibold text-ink"
                  >
                    {count}
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
            <button
              type="button"
              className="icon-btn md:hidden"
              aria-label="Open menu"
              aria-expanded={menuOpen}
              onClick={() => setMenuOpen(true)}
            >
              <Menu size={22} />
            </button>
          </div>
        </nav>
      </header>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            ref={menuRef}
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
            tabIndex={-1}
            className="fixed inset-0 z-[60] flex flex-col bg-ink outline-none md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
          >
            <div className="flex h-[72px] items-center justify-between px-5">
              <Logo />
              <button type="button" className="icon-btn" aria-label="Close menu" data-autofocus onClick={closeMenu}>
                <X size={24} />
              </button>
            </div>
            <ul className="flex flex-1 flex-col justify-center gap-2 px-8">
              {LINKS.map((l, i) => (
                <motion.li
                  key={l.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + i * 0.07, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                >
                  <button
                    type="button"
                    onClick={() => handleNav(l.id)}
                    className="heading w-full py-3 text-left text-4xl text-white transition-colors hover:text-gold"
                  >
                    {l.label}
                  </button>
                </motion.li>
              ))}
            </ul>
            <div className="hairline mx-8 mb-10" />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
