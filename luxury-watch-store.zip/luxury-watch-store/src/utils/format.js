import { BRAND } from '../config/brand.js';

const formatter = new Intl.NumberFormat(BRAND.locale, {
  style: 'currency',
  currency: BRAND.currency,
  maximumFractionDigits: 0,
});

export const formatPrice = (value) => formatter.format(value);
export const clamp = (v, min, max) => Math.min(max, Math.max(min, v));
