// ─────────────────────────────────────────────────────────────
//  CHECKOUT INTEGRATION POINT
//
//  With no VITE_CHECKOUT_ENDPOINT set, checkout runs in DEMO mode:
//  nothing is charged and no order is created.
//
//  To go live, build a small server endpoint (Stripe Checkout, Shopify,
//  Lemon Squeezy, PayPal …) that:
//    1. receives  { items: [{ id, quantity, variant }] }
//    2. looks up the REAL prices on the server (never trust browser prices)
//    3. creates a hosted checkout session
//    4. replies   { "url": "https://…hosted-checkout-page…" }
//  then put that endpoint in .env as VITE_CHECKOUT_ENDPOINT.
// ─────────────────────────────────────────────────────────────
const ENDPOINT = import.meta.env.VITE_CHECKOUT_ENDPOINT;

export const CHECKOUT_MODE = ENDPOINT ? 'live' : 'demo';

export async function createCheckoutSession(lines) {
  if (!ENDPOINT) return { mode: 'demo' };
  const res = await fetch(ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      items: lines.map((l) => ({ id: l.product.id, quantity: l.qty, variant: l.variant })),
    }),
  });
  if (!res.ok) throw new Error('Checkout service error');
  const data = await res.json();
  if (!data || typeof data.url !== 'string') throw new Error('Checkout service returned no URL');
  return { mode: 'live', url: data.url };
}
