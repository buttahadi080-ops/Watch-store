import { lazy, Suspense, useEffect } from 'react';
import { Route, Routes, useLocation } from 'react-router-dom';
import { MotionConfig } from 'motion/react';
import { CartProvider } from './context/CartContext.jsx';
import { StoreUIProvider } from './context/StoreUIContext.jsx';
import { BRAND } from './config/brand.js';
import AnnouncementBar from './components/AnnouncementBar.jsx';
import Navbar from './components/Navbar.jsx';
import Footer from './components/Footer.jsx';
import CartDrawer from './components/CartDrawer.jsx';
import ProductViewer from './components/ProductViewer.jsx';
import SearchOverlay from './components/SearchOverlay.jsx';
import CheckoutModal from './components/CheckoutModal.jsx';
import Home from './pages/Home.jsx';
import NotFound from './pages/NotFound.jsx';
import Legal from './pages/Legal.jsx';

const ProductDetails = lazy(() => import('./pages/ProductDetails.jsx'));

function ScrollManager() {
  const { pathname, state } = useLocation();
  useEffect(() => {
    if (!state?.scrollTo) window.scrollTo({ top: 0, behavior: 'auto' });
  }, [pathname, state]);
  return null;
}

export default function App() {
  useEffect(() => {
    document.title = `${BRAND.name} — Timeless Elegance`;
  }, []);

  return (
    // "user" honours the visitor's reduced-motion setting for all motion animations.
    <MotionConfig reducedMotion="user">
      <CartProvider>
        <StoreUIProvider>
          <ScrollManager />
          <a
            href="#main"
            className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[100] focus:bg-gold focus:px-4 focus:py-2 focus:text-ink"
          >
            Skip to content
          </a>
          <AnnouncementBar />
          <Navbar />
          <main id="main">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route
                path="/product/:slug"
                element={
                  <Suspense fallback={<div className="min-h-[60dvh]" aria-busy="true" />}>
                    <ProductDetails />
                  </Suspense>
                }
              />
              <Route path="/privacy" element={<Legal kind="privacy" />} />
              <Route path="/terms" element={<Legal kind="terms" />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
          <ProductViewer />
          <SearchOverlay />
          <CartDrawer />
          <CheckoutModal />
        </StoreUIProvider>
      </CartProvider>
    </MotionConfig>
  );
}
