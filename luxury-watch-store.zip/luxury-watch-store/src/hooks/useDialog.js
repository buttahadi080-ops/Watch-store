import { useEffect, useRef } from 'react';

const FOCUSABLE = 'a[href],button:not([disabled]),input,select,textarea,[tabindex]:not([tabindex="-1"])';

/**
 * Accessible dialog behaviour: Escape to close, focus trap, body scroll lock
 * and focus restoration. `containerRef` must point at the dialog element.
 */
export function useDialog(open, onClose, containerRef) {
  // Keep the latest onClose without re-running the effect (which would reset focus) on every render.
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    if (!open) return undefined;
    const previouslyFocused = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const getFocusable = () => {
      const node = containerRef.current;
      if (!node) return [];
      return Array.from(node.querySelectorAll(FOCUSABLE)).filter((el) => el.offsetParent !== null);
    };

    const timer = setTimeout(() => {
      const node = containerRef.current;
      const target = node?.querySelector('[data-autofocus]') || getFocusable()[0] || node;
      target?.focus?.();
    }, 80);

    const onKey = (e) => {
      if (e.key === 'Escape') {
        closeRef.current();
      } else if (e.key === 'Tab') {
        const items = getFocusable();
        if (!items.length) return;
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);

    return () => {
      clearTimeout(timer);
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = previousOverflow;
      if (previouslyFocused && previouslyFocused.focus) previouslyFocused.focus();
    };
  }, [open, containerRef]);
}
