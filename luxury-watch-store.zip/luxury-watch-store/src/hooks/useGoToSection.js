import { useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

/** Smooth-scrolls to a section id on the home page (navigating home first if needed). */
export function useGoToSection() {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  return useCallback(
    (id) => {
      if (pathname === '/') {
        const el = document.getElementById(id);
        const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (id === 'home') window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
        else el?.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' });
      } else {
        navigate('/', { state: { scrollTo: id } });
      }
    },
    [pathname, navigate],
  );
}
