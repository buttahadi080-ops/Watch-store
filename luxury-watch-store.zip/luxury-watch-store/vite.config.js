import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: {
    // three.js is lazy-loaded only when a product has a 3D model, so it is
    // intentionally a large separate chunk.
    chunkSizeWarningLimit: 1200,
  },
});
